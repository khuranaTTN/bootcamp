var dateobj = new Date(); 
var B = dateobj.toString();
use(function () {
    return {
        message: B
    };
});
